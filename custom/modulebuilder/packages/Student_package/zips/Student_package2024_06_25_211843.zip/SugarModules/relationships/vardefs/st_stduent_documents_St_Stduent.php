<?php
// created: 2024-06-25 21:18:43
$dictionary["St_Stduent"]["fields"]["st_stduent_documents"] = array (
  'name' => 'st_stduent_documents',
  'type' => 'link',
  'relationship' => 'st_stduent_documents',
  'source' => 'non-db',
  'module' => 'Documents',
  'bean_name' => 'Document',
  'side' => 'right',
  'vname' => 'LBL_ST_STDUENT_DOCUMENTS_FROM_DOCUMENTS_TITLE',
);
