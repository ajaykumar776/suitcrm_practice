<?php
// created: 2024-06-30 11:05:35
$dictionary["loc_Country"]["fields"]["loc_country_loc_state"] = array (
  'name' => 'loc_country_loc_state',
  'type' => 'link',
  'relationship' => 'loc_country_loc_state',
  'source' => 'non-db',
  'module' => 'loc_State',
  'bean_name' => false,
  'side' => 'right',
  'vname' => 'LBL_LOC_COUNTRY_LOC_STATE_FROM_LOC_STATE_TITLE',
);
