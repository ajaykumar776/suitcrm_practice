<?php
// created: 2024-06-30 11:05:35
$dictionary["loc_State"]["fields"]["loc_state_loc_city"] = array (
  'name' => 'loc_state_loc_city',
  'type' => 'link',
  'relationship' => 'loc_state_loc_city',
  'source' => 'non-db',
  'module' => 'loc_City',
  'bean_name' => false,
  'side' => 'right',
  'vname' => 'LBL_LOC_STATE_LOC_CITY_FROM_LOC_CITY_TITLE',
);
