<?php
 // created: 2024-06-30 11:05:35
$layout_defs["loc_State"]["subpanel_setup"]['loc_state_loc_city'] = array (
  'order' => 100,
  'module' => 'loc_City',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_LOC_STATE_LOC_CITY_FROM_LOC_CITY_TITLE',
  'get_subpanel_data' => 'loc_state_loc_city',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
